/** Automatically generated file. DO NOT MODIFY */
package com.app.weather;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}