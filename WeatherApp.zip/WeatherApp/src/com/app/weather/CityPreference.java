package com.app.weather;

import android.app.Activity;
import android.content.SharedPreferences;

public class CityPreference {
	   
    SharedPreferences prefs;
     
    public CityPreference(Activity weatherActivity){
        prefs = weatherActivity.getPreferences(Activity.MODE_PRIVATE);
    }

	// If the user has not chosen a city yet, return
    String getCity(){
        return prefs.getString("city", "Sydney, AU");        
    }
     
    void setCity(String city){
        prefs.edit().putString("city", city).commit();
    }
    
}
